-- QBCore client object (safe to require; ESX path doesn't need it)
if GetResourceState('qb-core') ~= 'missing' then
    QBCore = exports['qb-core']:GetCoreObject()
end

local function getJob()
    if Config.Framework == "qbcore" then
        local data = QBCore.Functions.GetPlayerData()
        return (data and data.job and data.job.name) or "unemployed"
    else
        return (ESX and ESX.GetPlayerData and ESX.GetPlayerData().job and ESX.GetPlayerData().job.name) or "unemployed"
    end
end

local function canUnseal(job)
    return Config.UnsealJobs[job] == true
end

-- QBCore: handler when item is used (server sends full item with info)
RegisterNetEvent('evidence:client:useBag', function(item)
    local job = getJob()
    local sealed = item.info and item.info.sealed
    local bagId = (item.info and item.info.bagId) or "UNKNOWN"

    exports['qb-menu']:openMenu({
        { header = "👜 Evidence Bag " .. bagId, txt = "Choose an option", isMenuHeader = true },
        {
            header = "👀 Inspect",
            txt = "View bag details",
            params = { event = "evidence:client:inspectBag" }
        },
        {
            header = "🔒 Seal Bag",
            txt = "Seal this bag (no more items can be added)",
            hidden = (job ~= "police" or sealed),
            params = { event = "evidence:client:sealBag" }
        },
        {
            header = "🔓 Unseal Bag",
            txt = "Unseal bag and retrieve contents",
            hidden = (not canUnseal(job) or not sealed),
            params = { event = "evidence:client:unsealBag" }
        },
    })
end)

-- ESX: usable item triggers with maybe incomplete data; we rely on server events
RegisterNetEvent('evidence:client:useBag_esx', function(payload)
    local job = getJob()
    local bagId = "UNKNOWN"
    local sealed = false
    if payload and payload.bag and payload.bag.metadata then
        bagId = payload.bag.metadata.bagId or "UNKNOWN"
        sealed = payload.bag.metadata.sealed or false
    end

    if GetResourceState('qb-menu') == 'started' then
        exports['qb-menu']:openMenu({
            { header = "👜 Evidence Bag " .. bagId, txt = "Choose an option", isMenuHeader = true },
            { header = "👀 Inspect", txt = "View bag details", params = { event = "evidence:client:inspectBag" } },
            {
                header = "🔒 Seal Bag",
                txt = "Seal this bag",
                hidden = (job ~= "police" or sealed),
                params = { event = "evidence:client:sealBag" }
            },
            {
                header = "🔓 Unseal Bag",
                txt = "Unseal bag and retrieve contents",
                hidden = (not canUnseal(job) or not sealed),
                params = { event = "evidence:client:unsealBag" }
            },
        })
    else
        -- Fallback if qb-menu not present
        TriggerServerEvent("evidence:server:inspect")
    end
end)

-- Menu button events -> server
RegisterNetEvent('evidence:client:inspectBag', function()
    TriggerServerEvent("evidence:server:inspect")
end)

RegisterNetEvent('evidence:client:sealBag', function()
    TriggerServerEvent("evidence:server:seal")
end)

RegisterNetEvent('evidence:client:unsealBag', function()
    TriggerServerEvent("evidence:server:unseal")
end)

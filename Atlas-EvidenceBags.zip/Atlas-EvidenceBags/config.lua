Config = {}

-- "qbcore" or "esx"
Config.Framework = "qbcore"

-- The evidence bag item name
Config.EvidenceItem = "evidence_bag"

-- Max distinct item entries per bag (each entry is an itemName + amount pair)
Config.MaxEvidenceItems = 5

-- Who can unseal
Config.UnsealJobs = { police = true, judge = true }

-- Show chat line as well as Notify for some actions
Config.ChatEcho = true

INSERT INTO items (name, label, weight) VALUES
('evidence_bag', 'Evidence Bag', 1);

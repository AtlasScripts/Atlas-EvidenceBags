fx_version 'cerulean'
game 'gta5'

author 'Atlas Scripts'
description 'Evidence Bag System'
version '1.2.0'

lua54 'yes'

shared_scripts {
    'config.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua', -- optional; not required unless you extend logging
    'server.lua'
}

client_scripts {
    'client.lua'
}

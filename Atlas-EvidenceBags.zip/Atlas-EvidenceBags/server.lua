local QBCore, ESX = nil, nil
local isQB = (Config.Framework == "qbcore")

if isQB then
    QBCore = exports['qb-core']:GetCoreObject()
else
    ESX = exports['es_extended']:getSharedObject()
end

-- ====== Utilities ======
local function IsJobAllowedToUnseal(jobName)
    return Config.UnsealJobs[jobName] == true
end

local function GenerateEvidenceID()
    return ("EB-%05d"):format(math.random(10000, 99999))
end

-- Get player's job name
local function GetJobName(src)
    if isQB then
        local Player = QBCore.Functions.GetPlayer(src)
        return Player and Player.PlayerData.job.name or "unemployed"
    else
        local xPlayer = ESX.GetPlayerFromId(src)
        return xPlayer and xPlayer.job and xPlayer.job.name or "unemployed"
    end
end

-- Notify wrapper
local function Notify(src, msg, typ)
    typ = typ or "primary"
    if isQB then
        TriggerClientEvent("QBCore:Notify", src, msg, typ)
    else
        TriggerClientEvent("esx:showNotification", src, msg)
    end
    if Config.ChatEcho then
        TriggerClientEvent('chat:addMessage', src, { args = {"Evidence", msg} })
    end
end

-- Fetch first unsealed, not-full evidence bag slot+item
local function FindOpenBag(src)
    if isQB then
        local Player = QBCore.Functions.GetPlayer(src)
        if not Player then return nil, nil end
        for slot, item in pairs(Player.PlayerData.items or {}) do
            if item and item.name == Config.EvidenceItem and item.info and item.info.sealed == false then
                local list = item.info.items or {}
                if #list < Config.MaxEvidenceItems then
                    return slot, item
                end
            end
        end
        return nil, nil
    else
        -- ESX + ox_inventory path
        -- ox_inventory exposes metadata; use exports to read player inventory
        local inv = exports.ox_inventory:GetInventory(src, false)
        if not inv or not inv.items then return nil, nil end
        for _, entry in pairs(inv.items) do
            if entry and entry.name == Config.EvidenceItem then
                local info = entry.metadata
                if info and info.sealed == false then
                    local list = info.items or {}
                    if #list < Config.MaxEvidenceItems then
                        return entry.slot, entry -- slot is required for updates
                    end
                end
            end
        end
        return nil, nil
    end
end

-- Get first evidence bag (any state) for actions like seal/unseal/inspect
local function FindAnyBag(src)
    if isQB then
        local Player = QBCore.Functions.GetPlayer(src)
        if not Player then return nil, nil end
        for slot, item in pairs(Player.PlayerData.items or {}) do
            if item and item.name == Config.EvidenceItem and item.info then
                return slot, item
            end
        end
        return nil, nil
    else
        local inv = exports.ox_inventory:GetInventory(src, false)
        if not inv or not inv.items then return nil, nil end
        for _, entry in pairs(inv.items) do
            if entry and entry.name == Config.EvidenceItem and entry.metadata then
                return entry.slot, entry
            end
        end
        return nil, nil
    end
end

-- Update a bag's metadata in place
local function UpdateBagInfo(src, slot, info)
    if isQB then
        local Player = QBCore.Functions.GetPlayer(src)
        if not Player then return false end
        local item = Player.PlayerData.items[slot]
        if not item or item.name ~= Config.EvidenceItem then return false end
        item.info = info
        -- QBCore convenience: force-set the slot again to sync
        Player.Functions.SetInventory(Player.PlayerData.items, true)
        return true
    else
        -- ESX + ox_inventory
        return exports.ox_inventory:SetMetadata(src, slot, info)
    end
end

-- Remove a bag item and give back its contents (unseal)
local function UnsealAndReturnContents(src, slot, info)
    if isQB then
        local Player = QBCore.Functions.GetPlayer(src)
        if not Player then return false end
        -- Remove the bag
        Player.Functions.RemoveItem(Config.EvidenceItem, 1, slot)
        -- Return items
        for _, v in ipairs(info.items or {}) do
            Player.Functions.AddItem(v.item, v.amount)
            TriggerClientEvent("inventory:client:ItemBox", src, QBCore.Shared.Items[v.item], "add")
        end
        return true
    else
        -- ESX + ox_inventory
        -- Remove the bag at the slot
        local ok = exports.ox_inventory:RemoveItem(src, Config.EvidenceItem, 1, nil, slot)
        if not ok then return false end
        for _, v in ipairs(info.items or {}) do
            exports.ox_inventory:AddItem(src, v.item, v.amount)
        end
        return true
    end
end

-- ====== Usable Item (open third-eye/quick menu) ======
if isQB then
    QBCore.Functions.CreateUseableItem(Config.EvidenceItem, function(source, item)
        TriggerClientEvent("evidence:client:useBag", source, item)
    end)
else
    -- ESX: rely on ox_inventory's metadata; usable item opens menu
    ESX.RegisterUsableItem(Config.EvidenceItem, function(source)
        -- Try to find the first bag and send it down; client also has a safe fallback
        local slot, bag = FindAnyBag(source)
        TriggerClientEvent("evidence:client:useBag_esx", source, { slot = slot, bag = bag })
    end)
end

-- ====== COMMANDS ======

-- /bagitem [targetId] [itemName] [amount]
RegisterCommand("bagitem", function(source, args)
    local src = source
    local job = GetJobName(src)
    if job ~= "police" then
        return Notify(src, "You are not authorized to bag evidence.", "error")
    end

    local targetId  = tonumber(args[1])
    local itemName  = tostring(args[2] or "")
    local amount    = tonumber(args[3] or 1)
    if not targetId or itemName == "" or amount <= 0 then
        return Notify(src, "Usage: /bagitem [id] [item] [amount]", "error")
    end

    if isQB then
        local Officer = QBCore.Functions.GetPlayer(src)
        local Suspect = QBCore.Functions.GetPlayer(targetId)
        if not Officer or not Suspect then return Notify(src, "Invalid target.", "error") end

        local suspectItem = Suspect.Functions.GetItemByName(itemName)
        if not suspectItem or suspectItem.amount < amount then
            return Notify(src, "Target does not have enough of that item.", "error")
        end

        if not Suspect.Functions.RemoveItem(itemName, amount) then
            return Notify(src, "Failed to remove item from target.", "error")
        end
        TriggerClientEvent("inventory:client:ItemBox", targetId, QBCore.Shared.Items[itemName], "remove")

        -- Try to add to an existing open (unsealed, not-full) bag
        local slot, bag = FindOpenBag(src)
        if slot and bag then
            local info = bag.info
            info.items = info.items or {}
            table.insert(info.items, { item = itemName, amount = amount })
            UpdateBagInfo(src, slot, info)
            return Notify(src, ("Added %sx %s to Evidence Bag %s."):format(amount, itemName, info.bagId), "success")
        end

        -- Create a new bag
        local info = {
            bagId = GenerateEvidenceID(),
            officer = (Officer.PlayerData.charinfo.firstname or "") .. " " .. (Officer.PlayerData.charinfo.lastname or ""),
            officerId = Officer.PlayerData.citizenid,
            seizedFrom = (Suspect.PlayerData.charinfo.firstname or "") .. " " .. (Suspect.PlayerData.charinfo.lastname or ""),
            suspectId = Suspect.PlayerData.citizenid,
            date = os.date("%Y-%m-%d %H:%M:%S"),
            sealed = false,
            items = { { item = itemName, amount = amount } },
        }
        Officer.Functions.AddItem(Config.EvidenceItem, 1, false, info)
        TriggerClientEvent("inventory:client:ItemBox", src, QBCore.Shared.Items[Config.EvidenceItem], "add")
        return Notify(src, ("New Evidence Bag %s created."):format(info.bagId), "success")

    else
        -- ESX + ox_inventory
        local xOfficer = ESX.GetPlayerFromId(src)
        local xSuspect = ESX.GetPlayerFromId(targetId)
        if not xOfficer or not xSuspect then return Notify(src, "Invalid target.", "error") end

        local susInv = exports.ox_inventory:GetItem(targetId, itemName, nil, true)
        local count = 0
        for _, it in ipairs(susInv or {}) do count = count + (it.count or 0) end
        if count < amount then return Notify(src, "Target does not have enough of that item.", "error") end

        local ok = exports.ox_inventory:RemoveItem(targetId, itemName, amount)
        if not ok then return Notify(src, "Failed to remove item from target.", "error") end

        local slot, bag = FindOpenBag(src)
        if slot and bag then
            local info = bag.metadata
            info.items = info.items or {}
            table.insert(info.items, { item = itemName, amount = amount })
            exports.ox_inventory:SetMetadata(src, slot, info)
            return Notify(src, ("Added %sx %s to Evidence Bag %s."):format(amount, itemName, info.bagId), "success")
        end

        -- New bag with metadata
        local info = {
            bagId = GenerateEvidenceID(),
            officer  = xOfficer.getName(),
            officerId = xOfficer.identifier,
            seizedFrom = xSuspect.getName(),
            suspectId  = xSuspect.identifier,
            date = os.date("%Y-%m-%d %H:%M:%S"),
            sealed = false,
            items = { { item = itemName, amount = amount } },
        }
        exports.ox_inventory:AddItem(src, Config.EvidenceItem, 1, info)
        return Notify(src, ("New Evidence Bag %s created."):format(info.bagId), "success")
    end
end, false)

-- /sealbag  (seals the first found unsealed bag)
RegisterCommand("sealbag", function(source)
    local src = source
    local job = GetJobName(src)
    if job ~= "police" then return Notify(src, "You are not authorized to seal evidence bags.", "error") end

    local slot, bag = FindAnyBag(src)
    if not slot or not bag then return Notify(src, "You don't have an evidence bag.", "error") end

    local info = isQB and bag.info or bag.metadata
    if info.sealed then return Notify(src, "This bag is already sealed.", "error") end
    if not info.items or #info.items == 0 then return Notify(src, "Cannot seal an empty bag.", "error") end

    info.sealed = true
    info.sealedDate = os.date("%Y-%m-%d %H:%M:%S")
    UpdateBagInfo(src, slot, info)
    Notify(src, ("Evidence Bag %s has been sealed."):format(info.bagId), "success")
end, false)

-- /unsealbag  (PD/Judge only)
RegisterCommand("unsealbag", function(source)
    local src = source
    local job = GetJobName(src)
    if not IsJobAllowedToUnseal(job) then
        return Notify(src, "You are not authorized to unseal evidence bags.", "error")
    end

    local slot, bag = FindAnyBag(src)
    if not slot or not bag then return Notify(src, "You don't have an evidence bag.", "error") end

    local info = isQB and bag.info or bag.metadata
    if not info.sealed then return Notify(src, "This bag is not sealed yet.", "error") end

    local ok = UnsealAndReturnContents(src, slot, info)
    if ok then
        Notify(src, ("Evidence Bag %s unsealed.\nSeized From: %s\nSealed By: %s"):format(
            info.bagId, info.seizedFrom or "Unknown", info.officer or "Unknown"), "success")
    else
        Notify(src, "Failed to unseal bag.", "error")
    end
end, false)

-- /inspectbag  (anyone can view details)
RegisterCommand("inspectbag", function(source)
    local src = source
    local slot, bag = FindAnyBag(src)
    if not slot or not bag then return Notify(src, "You don't have an evidence bag.", "error") end

    local info = isQB and bag.info or bag.metadata
    local lines = {}
    table.insert(lines, ("👜 Evidence Bag %s"):format(info.bagId or "UNKNOWN"))
    table.insert(lines, ("Seized From: %s (ID: %s)"):format(info.seizedFrom or "Unknown", info.suspectId or "N/A"))
    table.insert(lines, ("Officer: %s (ID: %s)"):format(info.officer or "Unknown", info.officerId or "N/A"))
    table.insert(lines, ("Date: %s"):format(info.date or "Unknown"))
    table.insert(lines, ("Sealed: %s"):format(info.sealed and "✅ Yes" or "❌ No"))
    table.insert(lines, "Contents:")
    if info.items and #info.items > 0 then
        for _, v in ipairs(info.items) do
            table.insert(lines, ("- %sx %s"):format(v.amount, v.item))
        end
    else
        table.insert(lines, "- (none)")
    end
    Notify(src, table.concat(lines, "\n"), "primary")
end, false)

-- ====== Client-triggered (third-eye menu) events ======
RegisterNetEvent("evidence:server:seal", function()
    local src = source
    ExecuteCommand("sealbag")
end)

RegisterNetEvent("evidence:server:unseal", function()
    local src = source
    ExecuteCommand("unsealbag")
end)

RegisterNetEvent("evidence:server:inspect", function()
    local src = source
    ExecuteCommand("inspectbag")
end)
